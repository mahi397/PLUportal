import React, { Component } from "react";
// import Table from "./Table";
import logo from "./logo.PNG";

class Portal extends Component {
  state = {
    aps: "",
    apsError: "",
    showLeft: false,
    showRight: false,

    leftData: [],
    rightData: [],
    data: [
      {
        "APS Number": "123456abcdefg",
        "Customer CIN": "1029384756",
        Flag: "TRUE",
        "Bot Timestamp": "2019-04-30T11:22:33.123Z"
      },
      {
        "APS Number": "234567bcdefgh",
        "Customer CIN": "6467388364",
        Flag: "TRUE",
        "Bot Timestamp": "2019-05-24T22:33:44.234Z"
      },
      {
        "APS Number": "234567bcdefgh",
        "Customer CIN": "5647382910",
        Flag: "FALSE",
        "Bot Timestamp": "2019-03-02T06:34:32.345Z"
      },
      {
        "APS Number": "564738bcdefgh",
        "Customer CIN": "5348782910",
        Flag: "TRUE",
        "Bot Timestamp": "2019-04-02T06:34:32.456Z"
      },
      {
        "APS Number": "564738bcdefgh",
        "Customer CIN": "5647967498",
        Flag: "FALSE",
        "Bot Timestamp": "2019-08-07T06:34:32.567Z"
      },
      {
        "APS Number": "345678cdefghi",
        "Customer CIN": "1920374855",
        Flag: "TRUE",
        "Bot Timestamp": "2019-01-23T12:13:14.678Z"
      },
      {
        "APS Number": "456789defghij",
        "Customer CIN": "0002736454",
        Flag: "TRUE",
        "Bot Timestamp": "2019-02-02T21:34:45.789Z"
      },
      {
        "APS Number": "456789defghij",
        "Customer CIN": "0002736454",
        Flag: "TRUE",
        "Bot Timestamp": "2019-04-03T23:03:40.567Z"
      }
    ]
  };

  // componentDidMount() {
  //   // Call our fetch function below once the component mounts
  //   this.callBackendAPI()
  //     .then(res => this.setState({ data: res.express }))
  //     .catch(err => console.log(err));
  // }
  // // Fetches our GET route from the Express server.
  // // (Note the route we are fetching matches the GET route from server.js
  // callBackendAPI = async () => {
  //   const response = await fetch("/");
  //   const body = await response.json();

  //   if (response.status !== 200) {
  //     throw Error(body.message);
  //   }
  //   return body;
  // };

  handleChange = event => {
    this.setState({ aps: event.target.value }, () => {
      this.validateAPS();
    });
  };

  validateAPS = () => {
    const { aps } = this.state;

    if (aps.length < 13 || aps.length > 13) {
      this.setState({ apsError: "APS Number must be 13 characters long" });
    }
    if (aps.length === 13) {
      this.setState({ apsError: null });
    }
  };

  handleReset = event => {
    this.setState({ aps: "", showLeft: false, showRight: false, apsError: "" });
  };

  handleSubmit = event => {
    event.preventDefault();
    const { aps, data } = this.state;
    console.log(aps);
    let filteredData = data.filter(i => i["APS Number"] === aps);

    console.log(filteredData);

    // let sameCIN = filteredData.filter(
    //   (i, j) => i["CustomerCIN"] === j["CustomerCIN"]
    // );

    if (filteredData.length === 2 /* & filteredData.map(i=> i["Flag"]) */) {
      this.setState(
        {
          showLeft: true,
          leftData: filteredData.filter(i => i.Flag === "TRUE")
        },
        () => console.log(this.state)
      );
      this.setState({
        showRight: true,
        rightData: filteredData.filter(i => i.Flag === "FALSE")
      });
    }
    // } else if (sameCIN.length > 1) {
    //   // console.log(sameCIN);
    //   let ts = sameCIN.filter(i => i["BotTimestamp"] /*islatest ;_;*/);
    // }

    // if (aps === "1") {
    //   this.setState({ showLeft: true });
    // }
    // if (aps === "2") {
    //   this.setState({ showLeft: true, showRight: true });
    // }
  };

  render() {
    const { showLeft, showRight } = this.state;

    return (
      <div
        className="container-fluid"
        style={{ height: "100vh", padding: "0px", margin: "0px" }}
      >
        <nav className="navbar navbar-dark">
          <a
            className="navbar-brand"
            href="https://www.rbs.com"
            style={{ fontSize: "40px" }}
          >
            <img
              src={logo}
              // class="d-inline-block align-top"
              alt=""
              // position= "Relative"
            />
            {/* RBS */}
          </a>
        </nav>
        <div className="card">
          <div
            className="card-body row justify-content-md-center"
            style={{ padding: "10 10 0 0", margin: "0px" }}
          >
            <form
              onSubmit={this.handleSubmit}
              onReset={this.handleReset}
              className="form-inline"
            >
              <div className="form-group">
                <div className="col col-lg-auto">
                  <label htmlFor="aps">APS Number: </label>
                </div>

                <div className="col-md-auto">
                  <input
                    type="text"
                    placeholder="Enter a valid APS number"
                    className={`form-control ${
                      this.state.apsError ? "is-invalid" : ""
                    }`}
                    id="aps"
                    value={this.state.aps}
                    onChange={this.handleChange}
                    onBlur={this.validateAPS}
                  />
                  <div className="invalid-feedback">{this.state.apsError}</div>
                </div>
              </div>

              <div className="col col-lg-2">
                <button type="submit" className="btn btn-primary">
                  Search
                </button>
              </div>

              <div className="col col-lg-2">
                <button type="reset" className="btn btn-primary">
                  Reset
                </button>
              </div>
            </form>
          </div>
        </div>
        <div>&nbsp;</div>
        <div
          className="card"
          style={{ height: "76vh", border: "0px", borderRadius: "0px" }}
        >
          <div
            className="card-body row justify-content-md-center"
            style={{ padding: "0px", margin: "0px" }}
          >
            <div className="col-lg" style={{ textAlign: "center" }}>
              <div style={{ paddingTop: "20px" }}>
                {showLeft && <LeftHeader />}
              </div>
              <div>&nbsp;</div>
              <div>{showLeft && <Table1 data={this.state.leftData} />}</div>
            </div>
            <div className="col-lg" style={{ textAlign: "center" }}>
              <div style={{ paddingTop: "20px" }}>
                {showRight && <RightHeader />}
              </div>
              <div>&nbsp;</div>
              <div>{showRight && <Table1 data={this.state.rightData} />}</div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const LeftHeader = () => {
  return <h4>Main Applicant</h4>;
};

const RightHeader = () => {
  return <h4>Joint Applicant</h4>;
};

const Table1 = props => {
  console.log(props);
  return (
    <table className="table">
      <tbody>
        <tr>
          <th>{Object.keys(props.data[0])[0]}</th>
          <td>{props.data[0]["APS Number"]}</td>
        </tr>
        <tr>
          <th>{Object.keys(props.data[0])[1]}</th>
          <td>{props.data[0]["Customer CIN"]}</td>
        </tr>
        <tr>
          <th>{Object.keys(props.data[0])[2]}</th>
          <td>{props.data[0]["Flag"]}</td>
        </tr>
        <tr>
          <th>{Object.keys(props.data[0])[3]}</th>
          <td>{props.data[0]["Bot Timestamp"]}</td>
        </tr>
      </tbody>
    </table>
  );
};

/*
 //first add an event listener for page load
 document.addEventListener( "DOMContentLoaded", get_json_data, false ); // get_json_data is the function name that will fire on page load
 //this function is in the event listener and will execute on page load
 function get_json_data(){
     // Relative URL of external json file
     var json_url = 'dummy.json';
     //Build the XMLHttpRequest (aka AJAX Request)
     xmlhttp = new XMLHttpRequest();
     xmlhttp.onreadystatechange = function() { 
         if (this.readyState == 4 && this.status == 200) {//when a good response is given do this
             var data = JSON.parse(this.responseText); // convert the response to a json object
             append_json(data);// pass the json object to the append_json function
         }
     }
     //set the request destination and type
     xmlhttp.open("POST", json_url, true);
     //set required headers for the request
     xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
     // send the request
     xmlhttp.send(); // when the request completes it will execute the code in onreadystatechange section
 }
 //this function appends the json data to the table 'gable'
 function append_json(data){
     var table = document.getElementById('table');
     data.forEach(function(object) {
         var tr = document.createElement('tr');
         tr.innerHTML = '<td>' + object.APSNumber + '</td>'+
         '<td>' + object.CustomerCIN + '</td>' +
         '<td>' + object.Flag + '</td>' +
         '<td>' + object.BotTimestamp + '</td>';
         table.appendChild(tr);
     });
 }
*/
export default Portal;
