import "bootstrap/dist/css/bootstrap.css";
import "./styles.css";
import React from "react";
import { render } from "react-dom";
import App from "./App";

render(<App />, document.getElementById("root"));

/*

https://www.google.com/search?q=get+entry+with+latest+timestamp+from+json+array&oq=get+entry+with+latest+timestamp+from+json+array&aqs=chrome..69i57.20023j0j1&sourceid=chrome&ie=UTF-8
https://stackoverflow.com/questions/36577205/what-is-the-elegant-way-to-get-the-latest-date-from-array-of-objects-in-client-s
https://stackoverflow.com/questions/7143399/min-max-of-dates-in-an-array
https://codereview.stackexchange.com/questions/104170/order-array-of-objects-by-date-property
https://stackoverflow.com/questions/30691066/sort-a-string-date-array
https://stackoverflow.com/questions/50467504/sort-an-array-of-timestamps-in-javascript?noredirect=1&lq=1
https://www.w3schools.com/html/tryit.asp?filename=tryhtml_table_headers
https://www.encodedna.com/javascript/populate-json-data-to-html-table-using-javascript.htm
https://stackoverflow.com/questions/40347411/how-to-display-json-data-with-reactjs-in-the-table
https://stackoverflow.com/questions/52840300/json-conversion-to-html-table-react?noredirect=1&lq=1
https://howtocreateapps.com/json-html-react-tutorial/

*/
