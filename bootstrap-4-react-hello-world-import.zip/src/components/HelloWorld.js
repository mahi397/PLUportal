import React, { Component } from "react";
import { HelloWorldHtml } from "./templates/HelloWorldHtml.jsx";

class HelloWorld extends Component {
  render() {
    return <HelloWorldHtml />;
  }
}

export default HelloWorld;
